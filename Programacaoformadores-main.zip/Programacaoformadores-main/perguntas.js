criaCartao(
    'Programação',
    'O que é Python?',
    'O Python é uma linguagem de programação'
)

criaCartao(
    'Programação',
    'O que é JavaScript?',
    'O JavaScript é uma linguagem de programação.'
)

criaCartao(
    'Programação',
    'O que é CSS?',
    'O CSS é uma lingugem de estilização!'
)

criaCartao(
    'Programação',
    'O que é HTML?',
    'O HTML é uma lingugem de estruturação e semântica do conteúdo.'
)
criaCartao(
    'Programação',
    'O que é VSCode?',
    'O Visual Studio Code é um editor de código com diversas integrações.s'
)
criaCartao(
    'Programação',
    'O que é GitHub?',
    'O GitHub é uma plataforma de desenvolvimento colaborativo que aloja projetos na nuvem.'
)